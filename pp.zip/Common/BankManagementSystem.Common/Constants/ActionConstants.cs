﻿namespace BankManagementSystem.Common.Constants
{
    public static class ActionConstants
    {
        public const string Index = "Index";
        public const string Success = "Success";
    }
}
