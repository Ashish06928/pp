﻿namespace BankManagementSystem.Models.Enum
{
    public enum TransactionType
    {
        Purchase,
        Deposit,
        Withdraw
    }
}
